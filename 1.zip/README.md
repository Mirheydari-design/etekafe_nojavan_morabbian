# دستیار هوشمند خادمان اعتکاف 🕊️

یک اپلیکیشن وب برای کمک به مربیان و خادمان اعتکاف در مدیریت و راهنمایی یاران.

## 📋 پیش‌نیازها

- Node.js (نسخه 14 یا بالاتر)
- npm یا yarn
- دسترسی به API بک‌اند

## 🚀 راه‌اندازی سریع

### مرحله 1: نصب وابستگی‌ها

```bash
npm install
```

### مرحله 2: تنظیم متغیرهای محیطی

فایل `.env.example` را کپی کنید و نام آن را `.env` بگذارید:

```bash
cp .env.example .env
```

سپس فایل `.env` را باز کنید و مقادیر را پر کنید:

```env
API_KEY=morabbiyane_eetekafe_nojavan
BASE_URL=https://selfclaude.flearning.ir/
API_ENDPOINT=v1/chat/completions
```

### مرحله 3: تولید فایل config.js

از متغیرهای محیطی، فایل `config.js` را تولید کنید:

```bash
npm run build:config
```

یا به صورت مستقیم:

```bash
node build-config.js
```

### مرحله 4: اجرای برنامه

#### ⭐ روش پیشنهادی: استفاده از سرور Node.js

```bash
npm start
```

سرور روی `http://localhost:3000` راه می‌افتد.

**مزایا:**
- ✅ به صورت خودکار `config.js` را از متغیرهای محیطی تولید می‌کند
- ✅ نیازی به اجرای دستور `build-config.js` نیست
- ✅ هر بار که سرور راه می‌افتد، config به‌روز می‌شود

#### روش‌های دیگر:

**گزینه 1: استفاده از Python**

```bash
# ابتدا config.js را تولید کنید
npm run build:config

# سپس سرور Python را راه‌اندازی کنید
python -m http.server 8000

# سپس در مرورگر باز کنید:
# http://localhost:8000/etekaf.html
```

**گزینه 2: استفاده از Node.js (http-server)**

```bash
# ابتدا config.js را تولید کنید
npm run build:config

# سپس سرور را راه‌اندازی کنید
npx http-server -p 8000
```

**گزینه 3: استفاده از PHP**

```bash
# ابتدا config.js را تولید کنید
npm run build:config

# سپس سرور PHP را راه‌اندازی کنید
php -S localhost:8000
```

## 📁 ساختار فایل‌ها

```
.
├── etekaf.html          # فایل اصلی اپلیکیشن
├── config.js            # فایل تنظیمات (از .env تولید می‌شود) ⚠️ نباید commit شود
├── config.js.example    # نمونه فایل تنظیمات
├── .env                 # متغیرهای محیطی ⚠️ نباید commit شود
├── .env.example         # نمونه متغیرهای محیطی
├── build-config.js      # اسکریپت تولید config.js
├── package.json         # وابستگی‌های Node.js
├── .gitignore          # فایل‌های نادیده گرفته شده
└── README.md           # این فایل
```

## 🔧 تنظیمات پیشرفته

### تغییر فرمت درخواست API

اگر API بک‌اند شما از فرمت متفاوتی استفاده می‌کند، فایل `etekaf.html` را ویرایش کنید و تابع `callGemini` را تغییر دهید.

### تغییر Header های درخواست

در تابع `callGemini`، بخش `headers` را ویرایش کنید:

```javascript
headers: { 
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${apiKey}`  // یا 'api-key': apiKey
}
```

### تغییر فرمت پاسخ

اگر API شما پاسخ را در فرمت دیگری برمی‌گرداند، بخش خواندن پاسخ را در تابع `callGemini` تغییر دهید:

```javascript
const responseText = data.choices?.[0]?.message?.content || 
                   data.content || 
                   // فرمت خاص API شما
```

## 🌐 راه‌اندازی روی سرور

برای راهنمای کامل و دقیق، فایل **[SETUP_GUIDE.md](SETUP_GUIDE.md)** را مطالعه کنید.

### روش 1: استفاده از سرور Node.js (پیشنهادی) ⭐

1. تمام فایل‌ها را روی سرور آپلود کنید
2. `npm install` را اجرا کنید
3. متغیرهای محیطی را تنظیم کنید (فایل `.env` یا متغیرهای سیستم)
4. `npm start` را اجرا کنید
5. (اختیاری) از PM2 برای مدیریت process استفاده کنید

**مزایا:**
- ✅ به صورت خودکار `config.js` را از متغیرهای محیطی تولید می‌کند
- ✅ نیازی به اجرای دستور `build-config.js` نیست

### روش 2: سرور استاتیک (Apache/Nginx)

1. تمام فایل‌ها را روی سرور آپلود کنید
2. فایل `.env` را با مقادیر واقعی پر کنید
3. دستور `npm run build:config` را اجرا کنید
4. از یک وب سرور (Apache, Nginx) استفاده کنید

### تنظیم متغیرهای محیطی

#### در فایل `.env` (پیشنهادی برای توسعه):
```env
API_KEY=morabbiyane_eetekafe_nojavan
BASE_URL=https://selfclaude.flearning.ir/
API_ENDPOINT=v1/chat/completions
PORT=3000
HOST=0.0.0.0
```

#### در cPanel:
1. به بخش "Environment Variables" یا "Setup Node.js App" بروید
2. متغیرهای زیر را اضافه کنید:
   - `API_KEY` = `morabbiyane_eetekafe_nojavan`
   - `BASE_URL` = `https://selfclaude.flearning.ir/`
   - `API_ENDPOINT` = `chat/completions`
   - `PORT` = `3000`
   - `HOST` = `0.0.0.0`

#### در سرور لینوکس (SSH):
```bash
# در فایل ~/.bashrc یا ~/.profile اضافه کنید:
export API_KEY="morabbiyane_eetekafe_nojavan"
export BASE_URL="https://selfclaude.flearning.ir/"
export API_ENDPOINT="chat/completions"
export PORT="3000"
export HOST="0.0.0.0"

# سپس:
source ~/.bashrc
```

#### در Docker:
```dockerfile
ENV API_KEY=morabbiyane_eetekafe_nojavan
ENV BASE_URL=https://selfclaude.flearning.ir/
ENV API_ENDPOINT=v1/chat/completions
ENV PORT=3000
ENV HOST=0.0.0.0
```

## 🔒 امنیت

- ⚠️ **هرگز** فایل `.env` یا `config.js` را در Git commit نکنید
- ✅ فایل `.gitignore` را بررسی کنید
- ✅ از HTTPS برای API استفاده کنید
- ✅ API key را در کد سمت کلاینت قرار ندهید (اگر ممکن است، از یک پروکسی استفاده کنید)

## 🐛 عیب‌یابی

### مشکل: "API key not configured"
- بررسی کنید فایل `config.js` وجود دارد
- بررسی کنید دستور `npm run build:config` را اجرا کرده‌اید
- بررسی کنید فایل `.env` را ایجاد کرده‌اید

### مشکل: "CORS Error"
- API بک‌اند باید CORS را برای دامنه شما فعال کند
- یا از یک پروکسی استفاده کنید

### مشکل: "404 Not Found"
- بررسی کنید `BASE_URL` و `API_ENDPOINT` درست هستند
- با تیم بک‌اند برای endpoint صحیح تماس بگیرید

## 📞 پشتیبانی

اگر مشکلی دارید:
1. لاگ‌های کنسول مرورگر را بررسی کنید (F12)
2. Network tab را بررسی کنید تا ببینید درخواست‌ها چگونه ارسال می‌شوند
3. با تیم بک‌اند برای فرمت دقیق API تماس بگیرید

## 📝 تغییرات

### نسخه 1.0.0
- ✅ پشتیبانی از متغیرهای محیطی
- ✅ اتصال به API بک‌اند سفارشی
- ✅ سیستم تولید خودکار config.js

---

**ساخته شده با ❤️ برای خادمان اعتکاف**

