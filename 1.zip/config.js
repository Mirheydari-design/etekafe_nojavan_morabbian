// فایل تنظیمات API
// این فایل برای تنظیمات هوش مصنوعی استفاده می‌شود

window.APP_CONFIG = {
    apiKey: "morabbiyane_eetekafe_nojavan",
    baseUrl: "https://selfclaude.flearning.ir/",
    apiEndpoint: "v1/chat/completions", // OpenAI-compatible API format
    
    // URL اصلی Google Sheet
    promptsUrl: "https://opensheet.elk.sh/1yxTX1rxNpJ_HDDLxpgi4CmqIJ3S3uZgII9phrjUl_uY/Sheet1"
    
    // اگر با خطای CORS مواجه شدید، از این URL استفاده کنید:
    // promptsUrl: "https://api.allorigins.win/raw?url=https://opensheet.elk.sh/1yxTX1rxNpJ_HDDLxpgi4CmqIJ3S3uZgII9phrjUl_uY/Sheet1"
};

